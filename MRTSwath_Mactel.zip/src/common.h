#ifndef COMMON_H
#define COMMON_H


#define MAX_SDS_DIMS (60)    /* Maximum number of SDSs that might be in an
                                input HDF-EOS file */
#define MYHDF_MAX_RANK (4)      /* maximum rank of an SDS expected */



#endif
