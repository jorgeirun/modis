#ifndef DEG2DMS_H
#define DEG2DMS_H                                               1,1           Top

int Deg2DMS (int projection_type, double *projection_parameters);
int degdms (double *deg, double *dms, char *code, char *check);

#endif
